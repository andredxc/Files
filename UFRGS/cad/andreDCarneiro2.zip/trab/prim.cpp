#include "trab.h"

int main(){

    prim();
    return 1;
}
