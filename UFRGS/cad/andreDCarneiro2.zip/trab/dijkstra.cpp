#include "trab.h"

int main(){

    fprintf(stderr, "RESULT: %d\n", dijkstra(1, 3));
    return 1;
}
