Andr� Dexheimer Carneiro - 00243653

Para compilar os programas:
	gcc -fopenmp pi.c -o pi
	gcc -fopenmp mm.c -o mm

Ao executar os programas, os resultados para pi ser�o impressos no terminal enquanto os da multiplica��o de matrizes ser�o escritos em um arquivo texto chamado "mm_out.txt" criado no diret�rio atual.

Os gr�ficos dos exerc�cios se encontram no formato de imagens .png.