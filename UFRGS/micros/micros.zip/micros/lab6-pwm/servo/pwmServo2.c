#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "libgalileo2.h"

int main(){

    setServoAngle(1, 90);
    return 0;
}
