sudo docker-compose build;sudo docker-compose up -d;echo "Done"
