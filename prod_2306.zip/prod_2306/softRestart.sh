echo "Performing soft restart"; sudo docker-compose down; sudo docker-compose build; sudo docker-compose up; echo "Done"
