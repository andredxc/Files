tail -n 50 -f /datadrive/docker/elasticsearch_logs/gc.log

