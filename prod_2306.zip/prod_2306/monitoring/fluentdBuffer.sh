du -h /datadrive/docker/fluentd_buffer
